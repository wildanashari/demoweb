<?php
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');
$yearNow = date('Y');

$title = 'First Ultimate Quality X-Suit Release';
$description = 'Iridescence X-Suit & Golden Pharaoh X-Suit (7-Star)';
$copyright = 'PUBG MOBILE';
$theme = '#000';
$image = 'https://www.pubgmobile.com/images/event/Iridescencex_suit/share/en.jpg';
$icon = 'https://www.pubgmobile.com/images/event/home/pubg_icon.png';
?>